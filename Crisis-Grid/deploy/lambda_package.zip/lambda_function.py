"""
Crisis Grid — Bedrock AI Decision Support Handler
Uses Claude 3 Sonnet via Amazon Bedrock for intelligent fault analysis
"""
import json
import boto3
import os
from datetime import datetime

bedrock = boto3.client("bedrock-runtime", region_name="us-east-1")
dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
sns = boto3.client("sns", region_name="us-east-1")

FAULT_TABLE = os.environ.get("FAULT_TABLE", "crisis-grid-faults")
SNS_TOPIC   = os.environ.get("SNS_TOPIC_ARN", "")

SUBSTATION_CONTEXT = {
    "SUB_YELAHANKA":       {"name": "Yelahanka",       "kv": 220, "area": "North Bangalore", "capacity_mva": 315},
    "SUB_WHITEFIELD":      {"name": "Whitefield",      "kv": 110, "area": "East Bangalore",  "capacity_mva": 160},
    "SUB_PEENYA":          {"name": "Peenya",          "kv": 220, "area": "West Bangalore",  "capacity_mva": 250},
    "SUB_ELECTRONIC_CITY": {"name": "Electronic City", "kv": 110, "area": "South Bangalore", "capacity_mva": 200},
    "SUB_HEBBAL":          {"name": "Hebbal",          "kv": 66,  "area": "North Bangalore", "capacity_mva": 100},
    "SUB_MARATHAHALLI":    {"name": "Marathahalli",    "kv": 66,  "area": "East Bangalore",  "capacity_mva": 80},
    "SUB_KORAMANGALA":     {"name": "Koramangala",     "kv": 66,  "area": "South-East",      "capacity_mva": 90},
    "SUB_RAJAJINAGAR":     {"name": "Rajajinagar",     "kv": 66,  "area": "West Bangalore",  "capacity_mva": 75},
    "SUB_YESHWANTHPUR":    {"name": "Yeshwanthpur",    "kv": 66,  "area": "NW Bangalore",    "capacity_mva": 85},
    "SUB_BTM":             {"name": "BTM Layout",      "kv": 66,  "area": "South Bangalore", "capacity_mva": 70},
    "SUB_JP_NAGAR":        {"name": "JP Nagar",        "kv": 66,  "area": "South Bangalore", "capacity_mva": 80},
    "SUB_INDIRANAGAR":     {"name": "Indiranagar",     "kv": 66,  "area": "East Bangalore",  "capacity_mva": 95},
}

REROUTE_PATHS = {
    "SUB_YELAHANKA":       ["SUB_PEENYA", "SUB_HEBBAL"],
    "SUB_WHITEFIELD":      ["SUB_MARATHAHALLI", "SUB_INDIRANAGAR"],
    "SUB_PEENYA":          ["SUB_YELAHANKA", "SUB_YESHWANTHPUR"],
    "SUB_ELECTRONIC_CITY": ["SUB_KORAMANGALA", "SUB_BTM"],
    "SUB_HEBBAL":          ["SUB_YELAHANKA", "SUB_YESHWANTHPUR"],
    "SUB_MARATHAHALLI":    ["SUB_WHITEFIELD", "SUB_INDIRANAGAR"],
    "SUB_KORAMANGALA":     ["SUB_BTM", "SUB_INDIRANAGAR"],
    "SUB_RAJAJINAGAR":     ["SUB_PEENYA", "SUB_YESHWANTHPUR"],
    "SUB_YESHWANTHPUR":    ["SUB_PEENYA", "SUB_RAJAJINAGAR"],
    "SUB_BTM":             ["SUB_KORAMANGALA", "SUB_JP_NAGAR"],
    "SUB_JP_NAGAR":        ["SUB_BTM", "SUB_KORAMANGALA"],
    "SUB_INDIRANAGAR":     ["SUB_MARATHAHALLI", "SUB_KORAMANGALA"],
}

CASCADE_MAP = {
    "SUB_YELAHANKA":       ["SUB_HEBBAL", "SUB_YESHWANTHPUR"],
    "SUB_PEENYA":          ["SUB_RAJAJINAGAR", "SUB_YESHWANTHPUR"],
    "SUB_WHITEFIELD":      ["SUB_MARATHAHALLI", "SUB_INDIRANAGAR"],
    "SUB_ELECTRONIC_CITY": ["SUB_KORAMANGALA", "SUB_BTM", "SUB_JP_NAGAR"],
    "SUB_HEBBAL":          ["SUB_YESHWANTHPUR"],
    "SUB_MARATHAHALLI":    ["SUB_INDIRANAGAR"],
    "SUB_KORAMANGALA":     ["SUB_BTM"],
    "SUB_BTM":             ["SUB_JP_NAGAR"],
}


def ask_bedrock(prompt):
    """Call Claude 3 Haiku via Bedrock"""
    body = json.dumps({
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 512,
        "messages": [{"role": "user", "content": prompt}]
    })
    response = bedrock.invoke_model(
        modelId="anthropic.claude-3-haiku-20240307-v1:0",
        body=body,
        contentType="application/json",
        accept="application/json"
    )
    result = json.loads(response["body"].read())
    return result["content"][0]["text"]


def build_bedrock_prompt(substation_id, fault_type, readings, failure_prob, severity, history):
    sub = SUBSTATION_CONTEXT.get(substation_id, {})
    reroute = [SUBSTATION_CONTEXT.get(r, {}).get("name", r) for r in REROUTE_PATHS.get(substation_id, [])]
    cascade = [SUBSTATION_CONTEXT.get(c, {}).get("name", c) for c in CASCADE_MAP.get(substation_id, [])]

    history_text = ""
    if history:
        history_text = f"\nRecent fault history at this substation: {json.dumps(history[-3:], default=str)}"

    return f"""You are an AI grid operator for BESCOM (Bangalore Electricity Supply Company).
A fault has been detected at a power substation. Analyse it and respond in JSON.

SUBSTATION: {sub.get('name', substation_id)} ({sub.get('area', '')})
VOLTAGE LEVEL: {sub.get('kv', '?')}kV | CAPACITY: {sub.get('capacity_mva', '?')} MVA
FAULT TYPE: {fault_type.replace('_', ' ').upper()}
FAILURE PROBABILITY: {failure_prob * 100:.1f}%
SEVERITY: {severity.upper()}

SENSOR READINGS:
- Voltage: {readings.get('voltage_v', 0):.1f}V
- Current: {readings.get('current_a', 0):.1f}A
- Frequency: {readings.get('frequency_hz', 50):.2f}Hz
- Transformer Temp: {readings.get('transformer_temp_c', 0):.1f}°C
- Load: {readings.get('load_percent', 0):.1f}%
- Health Score: {readings.get('health_score', 0):.0f}/100
- Power Factor: {readings.get('power_factor', 0):.3f}
{history_text}

AVAILABLE REROUTE PATHS: {', '.join(reroute)}
POTENTIAL CASCADE RISK TO: {', '.join(cascade) if cascade else 'None'}

Respond ONLY with valid JSON in this exact format:
{{
  "analysis": "2-3 sentence technical analysis of what is happening and why",
  "immediate_actions": ["action 1", "action 2", "action 3"],
  "cascade_risk": "assessment of cascade failure risk to neighbouring substations",
  "estimated_restoration": "time estimate for restoration",
  "citizen_message": "one sentence public notification for BESCOM app",
  "confidence": "high/medium/low"
}}"""


def log_to_dynamodb(substation_id, fault_type, severity, failure_prob, bedrock_analysis):
    try:
        table = dynamodb.Table(FAULT_TABLE)
        table.put_item(Item={
            "fault_id":         f"{substation_id}_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}",
            "substation_id":    substation_id,
            "timestamp":        datetime.utcnow().isoformat(),
            "fault_type":       fault_type,
            "severity":         severity,
            "failure_prob":     str(failure_prob),
            "ai_analysis":      bedrock_analysis.get("analysis", ""),
            "actions":          json.dumps(bedrock_analysis.get("immediate_actions", [])),
            "citizen_message":  bedrock_analysis.get("citizen_message", ""),
            "ttl":              int(datetime.utcnow().timestamp()) + 86400 * 30,
        })
    except Exception as e:
        print(f"DynamoDB log error: {e}")


def get_fault_history(substation_id):
    try:
        table = dynamodb.Table(FAULT_TABLE)
        resp = table.query(
            KeyConditionExpression="substation_id = :sid",
            ExpressionAttributeValues={":sid": substation_id},
            Limit=5,
            ScanIndexForward=False,
        )
        return resp.get("Items", [])
    except Exception:
        return []


def send_sns_alert(substation_name, citizen_message, severity):
    if not SNS_TOPIC:
        return
    try:
        sns.publish(
            TopicArn=SNS_TOPIC,
            Subject=f"BESCOM Alert — {severity.upper()} at {substation_name}",
            Message=citizen_message,
        )
    except Exception as e:
        print(f"SNS error: {e}")


def lambda_handler(event, context):
    headers = {"Access-Control-Allow-Origin": "*", "Content-Type": "application/json"}

    try:
        body = json.loads(event.get("body", "{}")) if isinstance(event.get("body"), str) else event
        substation_id = body.get("substation_id", "SUB_PEENYA")
        fault_type    = body.get("fault_type", "normal")
        readings      = body.get("sensor_readings", {})
        failure_prob  = float(body.get("failure_probability", 0))
        severity      = body.get("severity", "low")

        # only call Bedrock for actual anomalies
        if fault_type == "normal" or failure_prob < 0.35:
            return {
                "statusCode": 200,
                "headers": headers,
                "body": json.dumps({
                    "analysis": "All parameters within BESCOM operating limits.",
                    "immediate_actions": ["Continue standard monitoring"],
                    "cascade_risk": "None",
                    "estimated_restoration": "N/A",
                    "citizen_message": "",
                    "confidence": "high",
                    "source": "normal",
                })
            }

        # get history from DynamoDB
        history = get_fault_history(substation_id)

        # call Bedrock
        prompt   = build_bedrock_prompt(substation_id, fault_type, readings, failure_prob, severity, history)
        raw      = ask_bedrock(prompt)
        analysis = json.loads(raw)

        # log to DynamoDB
        log_to_dynamodb(substation_id, fault_type, severity, failure_prob, analysis)

        # send SNS if critical
        if severity in ("critical", "high"):
            sub_name = SUBSTATION_CONTEXT.get(substation_id, {}).get("name", substation_id)
            send_sns_alert(sub_name, analysis.get("citizen_message", ""), severity)

        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps({**analysis, "source": "bedrock"})
        }

    except json.JSONDecodeError as e:
        # Bedrock returned non-JSON — return raw text
        return {
            "statusCode": 200,
            "headers": headers,
            "body": json.dumps({
                "analysis": raw if "raw" in dir() else "Analysis unavailable",
                "immediate_actions": ["Check system logs"],
                "cascade_risk": "Unknown",
                "estimated_restoration": "Unknown",
                "citizen_message": "",
                "confidence": "low",
                "source": "bedrock_raw",
            })
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({"error": str(e)})
        }
